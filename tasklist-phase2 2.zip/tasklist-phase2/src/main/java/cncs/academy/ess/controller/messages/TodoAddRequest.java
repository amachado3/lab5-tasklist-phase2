package cncs.academy.ess.controller.messages;

public class TodoAddRequest {
    public String description;
    public int listId;
}
