package cncs.academy.ess.controller.messages;

public class TodoGetRequest {
    public int todoId;
}
