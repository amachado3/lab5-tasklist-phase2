package cncs.academy.ess.controller.messages;

public class UserLoginRequest {
    public String username;
    public String password;
}
