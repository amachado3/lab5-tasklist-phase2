package cncs.academy.ess.controller.messages;

public class UserAddRequest {
    public String username;
    public String password;
}
