package cncs.academy.ess.controller.messages;

public class ErrorMessage {
    public String error;

    public ErrorMessage(String message) {
        this.error = message;
    }

}
