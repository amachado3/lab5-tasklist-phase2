package cncs.academy.ess.controller.messages;

public class TodoListAddRequest {
    public String listName;
}
